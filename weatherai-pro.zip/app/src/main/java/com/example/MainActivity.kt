package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.data.api.GeocodingApiService
import com.example.data.api.WeatherApiService
import com.example.data.db.WeatherDatabase
import com.example.data.repository.GeminiRepository
import com.example.data.repository.WeatherRepository
import com.example.ui.WeatherViewModel
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // 1. Initialize DB and DAO
        val database = WeatherDatabase.getDatabase(applicationContext)
        val weatherDao = database.weatherDao()

        // 2. Initialize Moshi & OkHttp
        val moshi = Moshi.Builder()
            .addLast(KotlinJsonAdapterFactory())
            .build()
        val okHttpClient = OkHttpClient.Builder().build()

        // 3. Initialize Retrofit ApiServices
        val retrofitForecast = Retrofit.Builder()
            .baseUrl("https://api.open-meteo.com/")
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
        val weatherApi = retrofitForecast.create(WeatherApiService::class.java)

        val retrofitGeocoding = Retrofit.Builder()
            .baseUrl("https://geocoding-api.open-meteo.com/")
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
        val geocodingApi = retrofitGeocoding.create(GeocodingApiService::class.java)

        // 4. Initialize Repositories
        val weatherRepository = WeatherRepository(weatherApi, geocodingApi, weatherDao, moshi)
        val geminiRepository = GeminiRepository(moshi, okHttpClient)

        // 5. Instantiate Core WeatherViewModel using standard provider factory
        val viewModelFactory = WeatherViewModelFactory(weatherRepository, geminiRepository)
        val viewModel = ViewModelProvider(this, viewModelFactory)[WeatherViewModel::class.java]

        setContent {
            MyApplicationTheme {
                val currentScreen by viewModel.currentScreen.collectAsState()

                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    // Navigation Host Routing
                    when (currentScreen) {
                        "splash" -> {
                            SplashScreen(viewModel = viewModel) {
                                viewModel.navigateTo("onboarding")
                            }
                        }
                        "onboarding" -> {
                            OnboardingScreen(viewModel = viewModel)
                        }
                        "dashboard" -> {
                            DashboardScreen(viewModel = viewModel)
                        }
                        "history" -> {
                            HistoryScreen(viewModel = viewModel)
                        }
                        "settings" -> {
                            SettingsScreen(viewModel = viewModel)
                        }
                        else -> {
                            DashboardScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}

// Custom ViewModel Factory supporting clean manual Constructor Injection
class WeatherViewModelFactory(
    private val weatherRepository: WeatherRepository,
    private val geminiRepository: GeminiRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(WeatherViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return WeatherViewModel(weatherRepository, geminiRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class. Unable to instantiate.")
    }
}
