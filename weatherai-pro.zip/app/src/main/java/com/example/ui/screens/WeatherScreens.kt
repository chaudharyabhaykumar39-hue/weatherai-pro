package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.db.CityHistory
import com.example.data.model.DailyForecast
import com.example.data.model.GeocodingResult
import com.example.data.model.HourlyForecast
import com.example.data.model.WeatherResponse
import com.example.ui.SearchUiState
import com.example.ui.WeatherUiState
import com.example.ui.WeatherViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// Unified Color Palette based on active theme
data class AppThemeColors(
    val bgGradientStart: Color,
    val bgGradientEnd: Color,
    val cardBg: Color,
    val accentColor: Color,
    val textColor: Color
)

@Composable
fun getThemedColors(themeName: String): AppThemeColors {
    return when (themeName) {
        "Vibrant Palette" -> AppThemeColors(
            bgGradientStart = Color(0xFF1A1C1E),
            bgGradientEnd = Color(0xFF111214),
            cardBg = Color(0xFF282A2D),
            accentColor = Color(0xFF4791FF),
            textColor = Color.White
        )
        "Ocean Breeze" -> AppThemeColors(
            bgGradientStart = Color(0xFF0D47A1),
            bgGradientEnd = Color(0xFF1976D2),
            cardBg = Color(0x33000000),
            accentColor = Color(0xFF80DEEA),
            textColor = Color.White
        )
        "Forest Mist" -> AppThemeColors(
            bgGradientStart = Color(0xFF1B5E20),
            bgGradientEnd = Color(0xFF388E3C),
            cardBg = Color(0x22000000),
            accentColor = Color(0xFFA5D6A7),
            textColor = Color.White
        )
        "Cosmic Night" -> AppThemeColors(
            bgGradientStart = Color(0xFF120B24),
            bgGradientEnd = Color(0xFF2E1C4E),
            cardBg = Color(0x44000000),
            accentColor = Color(0xFFB39DDB),
            textColor = Color.White
        )
        "Sunset Gold" -> AppThemeColors(
            bgGradientStart = Color(0xFFE65100),
            bgGradientEnd = Color(0xFFF57C00),
            cardBg = Color(0x33000000),
            accentColor = Color(0xFFFFCC80),
            textColor = Color.White
        )
        else -> AppThemeColors(
            bgGradientStart = Color(0xFF1A1A1A),
            bgGradientEnd = Color(0xFF2C2C2C),
            cardBg = Color(0x22FFFFFF),
            accentColor = Color(0xFFBB86FC),
            textColor = Color.White
        )
    }
}

// 1. SPLASH SCREEN
@Composable
fun SplashScreen(viewModel: WeatherViewModel, onSplashFinished: () -> Unit) {
    val isHindi by viewModel.isHindi.collectAsState()
    
    LaunchedEffect(Unit) {
        delay(2500) // Splash delay
        onSplashFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF4791FF), Color(0xFF005AC1))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Elegant pulsing sun and cloud
            Icon(
                imageVector = Icons.Filled.WbCloudy,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier
                    .size(120.dp)
                    .testTag("splash_logo")
            )
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "WeatherAI Pro",
                fontSize = 36.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                letterSpacing = 1.5.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (isHindi) "स्मार्ट मौसम विश्लेषण एवं पूर्वानुमान" else "Smart Weather Analytics & Insights",
                fontSize = 14.sp,
                color = Color(0xFFDCEBFF),
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(48.dp))
            CircularProgressIndicator(
                color = Color.White,
                strokeWidth = 3.dp,
                modifier = Modifier.size(32.dp)
            )
        }
    }
}

// 2. ONBOARDING SCREEN
@Composable
fun OnboardingScreen(viewModel: WeatherViewModel) {
    val isHindi by viewModel.isHindi.collectAsState()
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF4791FF), Color(0xFF005AC1))
                )
            )
            .windowInsetsPadding(WindowInsets.safeDrawing),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Language Select Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = { viewModel.toggleLanguage() }) {
                    Text(
                        text = if (isHindi) "English" else "हिंदी",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Onboarding main illustration fallback (Pulsing graphic canvas)
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.CloudSync,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(140.dp)
                )
                Spacer(modifier = Modifier.height(32.dp))
                Text(
                    text = if (isHindi) "परिशुद्ध मौसम विज्ञान" else "Precision Forecasting",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = if (isHindi) {
                        "Open-Meteo तकनीक का उपयोग करके वास्तविक समय मौसम अपडेट प्राप्त करें तथा Gemini AI द्वारा संचालित पहनने योग्य कपड़े की सलाह पाएं।"
                    } else {
                        "Get real-time updates powered by Open-Meteo paired with smart Gemini AI custom outfit and outdoor advice."
                    },
                    fontSize = 15.sp,
                    color = Color(0xFFDCEBFF),
                    textAlign = TextAlign.Center,
                    lineHeight = 22.sp,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }

            // Steps Indicators and Next Action Button
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(bottom = 24.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.3f))
                    )
                }
                
                Button(
                    onClick = { viewModel.completeOnboarding() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White,
                        contentColor = Color(0xFF005AC1)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("get_started_button"),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = if (isHindi) "प्रारंभ करें" else "Get Started",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// 3. MAIN DASHBOARD SCREEN
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(viewModel: WeatherViewModel) {
    val context = LocalContext.current
    val isHindi by viewModel.isHindi.collectAsState()
    val isCelsius by viewModel.isCelsius.collectAsState()
    val isPremium by viewModel.isPremium.collectAsState()
    val activeThemeName by viewModel.activeTheme.collectAsState()
    val colors = getThemedColors(activeThemeName)
    val weatherState by viewModel.weatherUiState.collectAsState()
    val searchState by viewModel.searchUiState.collectAsState()
    val searchCount by viewModel.searchCount.collectAsState()
    val currentCity by viewModel.currentCityName.collectAsState()
    
    var searchQuery by remember { mutableStateOf("") }
    var showSearchDialog by remember { mutableStateOf(false) }
    var showRewardedAdDialog by remember { mutableStateOf(false) }
    var rewardedAdTaskToUnlock by remember { mutableStateOf("") } // "14day" or "themes"
    
    // Auto trigger interstitial ad simulation on search transitions
    LaunchedEffect(searchCount) {
        if (searchCount > 0 && searchCount % 3 == 0) {
            Toast.makeText(context, if (isHindi) "विज्ञापन लोड हो रहा है..." else "Loading AdMob Interstitial Ad...", Toast.LENGTH_SHORT).show()
            delay(1500)
            Toast.makeText(context, if (isHindi) "विज्ञापन से जुड़े रहने के लिए धन्यवाद! प्रीमियम लें।" else "Ad closure simulated! Upgrade to Premium to block ads.", Toast.LENGTH_LONG).show()
        }
    }

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = colors.bgGradientEnd.copy(alpha = 0.95f),
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = true,
                    onClick = { },
                    icon = { Icon(Icons.Filled.Cloud, contentDescription = null, tint = colors.accentColor) },
                    label = { Text(if (isHindi) "मुख्य" else "Home", color = Color.White) }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { viewModel.navigateTo("history") },
                    icon = { Icon(Icons.Filled.History, contentDescription = null, tint = Color.LightGray) },
                    label = { Text(if (isHindi) "इतिहास" else "History", color = Color.LightGray) }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { viewModel.navigateTo("settings") },
                    icon = { Icon(Icons.Filled.Settings, contentDescription = null, tint = Color.LightGray) },
                    label = { Text(if (isHindi) "सेटिंग्स" else "Settings", color = Color.LightGray) }
                )
            }
        },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(colors.bgGradientStart, colors.bgGradientEnd)
                    )
                )
                .padding(innerPadding)
        ) {
            // BACKDROP WEATHER ANIMATIONS
            when (weatherState) {
                is WeatherUiState.Success -> {
                    val code = (weatherState as WeatherUiState.Success).weather.current?.weatherCode ?: 0
                    when {
                        code == 0 -> SunnyAnimation()
                        code in 61..67 || code in 80..82 -> RainAnimation()
                        code in 71..77 || code in 85..86 -> SnowAnimation()
                    }
                }
                else -> {}
            }

            // MAIN CONTENT SCROLLABLE
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp)
            ) {
                // Header Row (Search & Action shortcuts)
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "WeatherAI",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            color = colors.textColor
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            // Location GPS quick fetch trigger
                            IconButton(
                                onClick = {
                                    // Default back to primary New Delhi / Simulated GPS detect
                                    viewModel.loadWeatherForLocation(28.6139, 77.2090, "Simulated GPS City", bypassCache = true)
                                    Toast.makeText(context, if (isHindi) "GPS स्थान सिमुलेट किया गया!" else "GPS Location simulated successfully!", Toast.LENGTH_SHORT).show()
                                },
                                colors = IconButtonDefaults.iconButtonColors(containerColor = colors.cardBg)
                            ) {
                                Icon(Icons.Filled.MyLocation, contentDescription = "Simulated GPS Detect", tint = colors.accentColor)
                            }

                            // Pull up Geo Search Box Trigger
                            IconButton(
                                onClick = { showSearchDialog = true },
                                colors = IconButtonDefaults.iconButtonColors(containerColor = colors.cardBg),
                                modifier = Modifier.testTag("search_trigger_button")
                            ) {
                                Icon(Icons.Filled.Search, contentDescription = "Search", tint = colors.accentColor)
                            }
                        }
                    }
                }

                // ADMOB BANNER AD
                if (!isPremium) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().testTag("admob_banner")
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .background(Color(0xFFE2E8F0), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("AD", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (isHindi) "विज्ञापन: विज्ञापन मुक्त मौसम ऐप अनुभव के लिए प्रीमियम लें!" else "AdMob: Block all advertisements with Pro upgrade!",
                                        fontSize = 12.sp,
                                        color = Color.White,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                                Button(
                                    onClick = { viewModel.setPremium(true) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFACC15)),
                                    contentPadding = PaddingValues(horizontal = 8.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text("UPGRADE", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // CURRENT WEATHER STATE
                when (val state = weatherState) {
                    is WeatherUiState.Loading -> {
                        item {
                            Box(
                                modifier = Modifier.fillMaxWidth().height(260.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(color = colors.accentColor)
                            }
                        }
                    }
                    is WeatherUiState.Error -> {
                        item {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = colors.cardBg),
                                shape = RoundedCornerShape(20.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(Icons.Filled.SignalWifiOff, null, tint = colors.accentColor, modifier = Modifier.size(48.dp))
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text(state.message, color = Color.White, textAlign = TextAlign.Center)
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Button(
                                        onClick = { viewModel.refreshCurrentWeather() },
                                        colors = ButtonDefaults.buttonColors(containerColor = colors.accentColor, contentColor = Color.Black)
                                    ) {
                                        Text(if (isHindi) "पुनः प्रयास करें" else "Try Again")
                                    }
                                }
                            }
                        }
                    }
                    is WeatherUiState.Success -> {
                        // Weather Panel Cards
                        item {
                            DashboardSummary(
                                cityName = state.cityName,
                                isHindi = isHindi,
                                isCelsius = isCelsius,
                                activeColors = colors,
                                weather = state.weather,
                                viewModel = viewModel
                            )
                        }

                        // METEO ALERT CARD
                        item {
                            MeteoAlertsPanel(isHindi = isHindi, colors = colors)
                        }

                        // GEMINI AI INSIGHT CARD
                        item {
                            GeminiAiInsightCard(
                                insightText = state.aiInsight,
                                isHindi = isHindi,
                                colors = colors
                            )
                        }

                        // HOURLY FORECAST
                        item {
                            HourlyForecastRow(
                                hourly = state.weather.hourly,
                                isHindi = isHindi,
                                isCelsius = isCelsius,
                                colors = colors,
                                viewModel = viewModel
                            )
                        }

                        // WEATHER METRIC PARAMETERS GRID
                        item {
                            WeatherParametersGrid(
                                current = state.weather.current,
                                isHindi = isHindi,
                                isCelsius = isCelsius,
                                colors = colors
                            )
                        }

                        // 7-DAY FORECAST WITH PREMIUM REWARDED AD GATEWAY
                        item {
                            SevenDayForecastPanel(
                                daily = state.weather.daily,
                                isHindi = isHindi,
                                isCelsius = isCelsius,
                                isPremiumUnlocked = isPremium,
                                colors = colors,
                                onUnlockTriggered = {
                                    rewardedAdTaskToUnlock = "14day"
                                    showRewardedAdDialog = true
                                },
                                viewModel = viewModel
                            )
                        }
                    }
                }
            }

            // GEO SEARCH BOX MODAL / POPUP
            if (showSearchDialog) {
                SearchCityPopUp(
                    isHindi = isHindi,
                    searchState = searchState,
                    searchQuery = searchQuery,
                    onQueryChanged = { searchQuery = it },
                    onSearchAction = { query -> viewModel.searchCityAndLoad(query) },
                    onResultSelected = { result ->
                        viewModel.loadWeatherForLocation(result.latitude, result.longitude, result.name)
                        showSearchDialog = false
                        viewModel.clearSearchIdle()
                        searchQuery = ""
                    },
                    onDismiss = {
                        showSearchDialog = false
                        viewModel.clearSearchIdle()
                        searchQuery = ""
                    }
                )
            }

            // SIMULATED REWARDED AD DIALOG
            if (showRewardedAdDialog) {
                SimulatedRewardedAd(
                    isHindi = isHindi,
                    taskLabel = if (rewardedAdTaskToUnlock == "14day") {
                        if (isHindi) "14-दिवसीय मौसम पूर्वानुमान" else "14-Day Extended Weather Forecast"
                    } else {
                        if (isHindi) "प्रीमियम मौसम रंग विषय" else "Premium Adaptive Weather Themes"
                    },
                    onAdCompleted = {
                        viewModel.setPremium(true)
                        showRewardedAdDialog = false
                        Toast.makeText(
                            context,
                            if (isHindi) "सफलता: सभी सुविधाएं पूर्णतः अनलॉक हो चुकी हैं!" else "Rewarded Ad Completed! Premium Weather AI Unlocked!",
                            Toast.LENGTH_LONG
                        ).show()
                    },
                    onDismiss = { showRewardedAdDialog = false }
                )
            }
        }
    }
}

// Sub-component: Dashboard summary display
@Composable
fun DashboardSummary(
    cityName: String,
    isHindi: Boolean,
    isCelsius: Boolean,
    activeColors: AppThemeColors,
    weather: WeatherResponse,
    viewModel: WeatherViewModel
) {
    val temp = weather.current?.temperature ?: 20.0
    val displayTemp = if (isCelsius) temp else (temp * 1.8 + 32)
    val feelsLike = weather.current?.apparentTemperature ?: 20.0
    val displayFeelsLike = if (isCelsius) feelsLike else (feelsLike * 1.8 + 32)
    val weatherDesc = viewModel.getWeatherCodeDescription(weather.current?.weatherCode ?: 0, isHindi)

    val currentThemeName = viewModel.activeTheme.collectAsState().value
    val isVibrantPalette = currentThemeName == "Vibrant Palette"

    val cardShape = if (isVibrantPalette) {
        RoundedCornerShape(bottomStart = 40.dp, bottomEnd = 40.dp)
    } else {
        RoundedCornerShape(28.dp)
    }

    val displayAccentColor = if (isVibrantPalette) {
        Color(0xFFE2E2E6)
    } else {
        activeColors.accentColor
    }

    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isVibrantPalette) Color.Transparent else activeColors.cardBg
        ),
        shape = cardShape,
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (isVibrantPalette) {
                    Modifier.background(
                        brush = Brush.verticalGradient(
                            colors = listOf(Color(0xFF4791FF), Color(0xFF005AC1))
                        ),
                        shape = cardShape
                    )
                } else Modifier
            )
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        cityName,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = activeColors.textColor
                    )
                    Text(
                        text = if (isHindi) "लाइव मौसम विश्लेषण" else "Live Weather Analytics",
                        fontSize = 12.sp,
                        color = if (isVibrantPalette) Color(0xFFDCEBFF) else activeColors.accentColor,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Icon(
                    imageVector = getWeatherIconComponent(weather.current?.weatherCode ?: 0),
                    contentDescription = weatherDesc,
                    tint = if (isVibrantPalette) Color.White else activeColors.accentColor,
                    modifier = Modifier.size(54.dp)
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Main Temp
            Text(
                text = "${String.format("%.1f", displayTemp)}${if (isCelsius) "°C" else "°F"}",
                fontSize = 68.sp,
                fontWeight = FontWeight.Black,
                color = activeColors.textColor,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Weather status label & Feels like
            Text(
                text = weatherDesc,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = if (isVibrantPalette) Color.White else activeColors.accentColor
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = if (isHindi) "महसूस हो रहा है: ${String.format("%.1f", displayFeelsLike)}${if (isCelsius) "°C" else "°F"}" else "Feels Like: ${String.format("%.1f", displayFeelsLike)}${if (isCelsius) "°C" else "°F"}",
                fontSize = 13.sp,
                color = if (isVibrantPalette) Color(0xFFE2E2E6) else Color.LightGray
            )
        }
    }
}

// Sub-component: MeteoAlerts Notifications Panel
@Composable
fun MeteoAlertsPanel(isHindi: Boolean, colors: AppThemeColors) {
    Card(
        colors = CardDefaults.cardColors(containerColor = colors.accentColor.copy(alpha = 0.15f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(Icons.Filled.Warning, contentDescription = "Alert", tint = colors.accentColor)
            Column {
                Text(
                    text = if (isHindi) "मौसम प्रोचेतावनी" else "MeteoAlert Pro",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = if (isHindi) "शाम 6:00 बजे हल्की मध्यम बूंदाबांदी का अंदेशा है।" else "Light showers predicted in current coordinates around sunset.",
                    fontSize = 11.sp,
                    color = Color.LightGray
                )
            }
        }
    }
}

// Sub-component: Gemini Intelligent Insight Card
@Composable
fun GeminiAiInsightCard(insightText: String, isHindi: Boolean, colors: AppThemeColors) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0x7F1E1B4B)), // deep custom purple tint
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.AutoAwesome,
                    contentDescription = null,
                    tint = colors.accentColor,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = if (isHindi) "Gemini AI मौसम सूझ-बूझ" else "Gemini AI Smart Insight",
                    color = colors.accentColor,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = insightText,
                color = Color.White,
                fontSize = 14.sp,
                lineHeight = 21.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

// Sub-component: Hourly Forecast row
@Composable
fun HourlyForecastRow(
    hourly: HourlyForecast?,
    isHindi: Boolean,
    isCelsius: Boolean,
    colors: AppThemeColors,
    viewModel: WeatherViewModel
) {
    if (hourly == null) return

    Column {
        Text(
            text = if (isHindi) "प्रति घंटे का पूर्वानुमान" else "Hourly Forecast",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            // Take first 12 hours
            val count = minOf(hourly.time.size, 12)
            items(List(count) { it }) { index ->
                val timeString = hourly.time[index].substringAfter("T") // get "14:00"
                val temp = hourly.temperatures[index]
                val displayTemp = if (isCelsius) temp else (temp * 1.8 + 32)
                val code = hourly.weatherCodes[index]

                Card(
                    colors = CardDefaults.cardColors(containerColor = colors.cardBg),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.width(72.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .padding(vertical = 12.dp, horizontal = 6.dp)
                            .fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(timeString, fontSize = 12.sp, color = Color.LightGray)
                        Spacer(modifier = Modifier.height(8.dp))
                        Icon(
                            imageVector = getWeatherIconComponent(code),
                            contentDescription = null,
                            tint = colors.accentColor,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "${String.format("%.0f", displayTemp)}°",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

// Sub-component: Detail metrics parameters grid
@Composable
fun WeatherParametersGrid(
    current: com.example.data.model.CurrentWeather?,
    isHindi: Boolean,
    isCelsius: Boolean,
    colors: AppThemeColors
) {
    if (current == null) return

    Column {
        Text(
            text = if (isHindi) "मौसम के विस्तृत आंकड़े" else "Weather Metrics Summary",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            modifier = Modifier.padding(bottom = 10.dp)
        )

        val parameters = listOf(
            Triple(
                if (isHindi) "आर्द्रता" else "Humidity",
                "${current.humidity}%",
                Icons.Filled.Water
            ),
            Triple(
                if (isHindi) "हवा की गति" else "Wind Speed",
                "${current.windSpeed} km/h",
                Icons.Filled.Air
            ),
            Triple(
                if (isHindi) "वायु दाब" else "Barometer",
                "${current.pressure} hPa",
                Icons.Filled.Speed
            ),
            Triple(
                if (isHindi) "दृश्यता" else "Visibility",
                "${current.visibility} km",
                Icons.Filled.Visibility
            ),
            Triple(
                if (isHindi) "यूवी सूचकांक" else "UV Index",
                "${current.uvIndex}",
                Icons.Filled.SolarPower
            ),
            Triple(
                if (isHindi) "सूर्यदेवता समय" else "Alert Status",
                "Normal",
                Icons.Filled.NotificationsActive
            )
        )

        // Draw standard 3 columns metrics using row/columns cleanly instead of FlowRow to support all compose platforms
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            for (row in 0 until 3) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    for (col in 0 until 2) {
                        val index = row * 2 + col
                        if (index < parameters.size) {
                            val param = parameters[index]
                            Card(
                                colors = CardDefaults.cardColors(containerColor = colors.cardBg),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("metric_card_${index}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(
                                        imageVector = param.third,
                                        contentDescription = null,
                                        tint = colors.accentColor,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Column {
                                        Text(param.first, fontSize = 12.sp, color = Color.LightGray)
                                        Text(param.second, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// Sub-component: 7-Day Forecast with premium rewarded block!
@Composable
fun SevenDayForecastPanel(
    daily: DailyForecast?,
    isHindi: Boolean,
    isCelsius: Boolean,
    isPremiumUnlocked: Boolean,
    colors: AppThemeColors,
    onUnlockTriggered: () -> Unit,
    viewModel: WeatherViewModel
) {
    if (daily == null) return

    Card(
        colors = CardDefaults.cardColors(containerColor = colors.cardBg),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                text = if (isHindi) "7-दिवसीय मौसम पूर्वानुमान" else "7-Day Weather Forecasting",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            // Show list (always allow first 3 days for free! Lock remaining 4 days under the Rewarded Ad / Premium check)
            val totalDays = daily.time.size
            val visibleDaysRange = if (isPremiumUnlocked) totalDays else 3

            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                for (index in 0 until visibleDaysRange) {
                    val rawDateString = daily.time[index]
                    val maxTemp = daily.maxTemperatures[index]
                    val minTemp = daily.minTemperatures[index]
                    val code = daily.weatherCodes[index]

                    val displayMax = if (isCelsius) maxTemp else (maxTemp * 1.8 + 32)
                    val displayMin = if (isCelsius) minTemp else (minTemp * 1.8 + 32)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(rawDateString, fontSize = 14.sp, color = Color.White, modifier = Modifier.weight(1f))
                        
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = getWeatherIconComponent(code),
                                contentDescription = null,
                                tint = colors.accentColor,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                viewModel.getWeatherCodeDescription(code, isHindi),
                                fontSize = 12.sp,
                                color = Color.LightGray
                            )
                        }

                        Text(
                            text = "${String.format("%.0f", displayMax)}°/ ${String.format("%.0f", displayMin)}°",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            textAlign = TextAlign.End,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // If not premium, show the locked summary button!
                if (!isPremiumUnlocked && totalDays > 3) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = onUnlockTriggered,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFACC15), contentColor = Color.Black),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().testTag("unlock_forecasting_button")
                    ) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isHindi) "14-दिवसीय पूर्वानुमान अनलॉक करें (विज्ञापन देखें)" else "Unlock 14-Day Forecast (Watch Ad)",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

// 4. HISTORIC SEARCHES / FAVORITES LIST SCREEN
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(viewModel: WeatherViewModel) {
    val listItems by viewModel.allHistory.collectAsState()
    val colors = getThemedColors(viewModel.activeTheme.collectAsState().value)
    val isHindi by viewModel.isHindi.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isHindi) "इतिहास एवं सहेजें" else "Forecast History") },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateTo("dashboard") }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.clearAllHistory() }) {
                        Icon(Icons.Filled.DeleteSweep, contentDescription = "Clear All", tint = Color.LightGray)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colors.bgGradientStart,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(colors.bgGradientStart, colors.bgGradientEnd)
                    )
                )
                .padding(innerPadding)
        ) {
            if (listItems.isEmpty()) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.HelpOutline,
                        contentDescription = null,
                        modifier = Modifier.size(72.dp),
                        tint = colors.accentColor
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = if (isHindi) "कोई इतिहास मौजूद नहीं है" else "Search History is Empty",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isHindi) "शहरों को खोजना शुरू करें और वे यहाँ सहेजे जाएंगे।" else "Search city names, load forecasts, and quick routes will be saved here.",
                        color = Color.LightGray,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(listItems) { city ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = colors.cardBg),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.loadWeatherForLocation(city.latitude, city.longitude, city.cityName)
                                    viewModel.navigateTo("dashboard")
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(city.cityName, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                    Text("Lat: ${String.format("%.3f", city.latitude)}  Lng: ${String.format("%.3f", city.longitude)}", fontSize = 11.sp, color = Color.LightGray)
                                }

                                Row {
                                    IconButton(onClick = { viewModel.deleteHistoryItem(city) }) {
                                        Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = Color.LightGray)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 5. SETTINGS SCREEN
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: WeatherViewModel) {
    val isHindi by viewModel.isHindi.collectAsState()
    val isCelsius by viewModel.isCelsius.collectAsState()
    val isPremium by viewModel.isPremium.collectAsState()
    val activeThemeName by viewModel.activeTheme.collectAsState()
    val colors = getThemedColors(activeThemeName)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isHindi) "मौसम सहायता एवं सेटिंग" else "WeatherAI settings") },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateTo("dashboard") }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colors.bgGradientStart,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(colors.bgGradientStart, colors.bgGradientEnd)
                    )
                )
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Language Select Panel
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = colors.cardBg),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(if (isHindi) "भाषा सेटिंग्स" else "Application Language", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text(if (isHindi) "हिंदी भाषा सक्रिय है" else "English language is active", fontSize = 12.sp, color = Color.LightGray)
                        }

                        Button(
                            onClick = { viewModel.toggleLanguage() },
                            colors = ButtonDefaults.buttonColors(containerColor = colors.accentColor)
                        ) {
                            Text(if (isHindi) "English" else "हिंदी", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Temperature Metrics Metric vs Imperial
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = colors.cardBg),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(if (isHindi) "तापमान की इकाई" else "Temperature Metric", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text(if (isCelsius) "सेल्सियस (°C) सक्रिय" else "फ़ारेनहाइट (°F) सक्रिय", fontSize = 12.sp, color = Color.LightGray)
                        }

                        Switch(
                            checked = isCelsius,
                            onCheckedChange = { viewModel.toggleUnit() },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = colors.accentColor,
                                checkedTrackColor = colors.accentColor.copy(alpha = 0.5f)
                            )
                        )
                    }
                }
            }

            // PREMIUM THEMES SELECTION
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = colors.cardBg),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (isHindi) "मौसम रंग थीम्स" else "Adaptive Themes",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = if (isHindi) "विभिन्न मौसम रंग शैली चुनें!" else "Change background themes!",
                            fontSize = 12.sp,
                            color = Color.LightGray
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        val themesList = listOf("Vibrant Palette", "Ocean Breeze", "Forest Mist", "Cosmic Night", "Sunset Gold")
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            themesList.forEach { themeName ->
                                val actsSelected = activeThemeName == themeName
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            if (actsSelected) colors.accentColor else Color(0x33FFFFFF)
                                        )
                                        .clickable {
                                            viewModel.setTheme(themeName)
                                        }
                                        .padding(8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = themeName.substringBefore(" "),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (actsSelected) Color.Black else Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // ADMOB CONFIGURATION UTILITIES
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = colors.cardBg),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(if (isHindi) "AdMob विज्ञापनों का नियंत्रण" else "AdMob Configuration Console", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Banner ID: ca-app-pub-3940256099942544/6300978111 (Test)", fontSize = 11.sp, color = colors.accentColor)
                        Text("Interstitial ID: ca-app-pub-3940256099942544/1033173712 (Test)", fontSize = 11.sp, color = colors.accentColor)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(if (isHindi) "प्रीमियम प्रो लेने पर विज्ञापन स्वतः अवरुद्ध हो जाएंगे।" else "Test Ads are loaded by default. Real AdMob IDs replace test IDs prior to publishing.", fontSize = 11.sp, color = Color.LightGray)
                    }
                }
            }

            // APP METADATA
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = colors.cardBg),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("WeatherAI Pro v1.0", fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Open-Meteo & Gemini-Flash Client", fontSize = 11.sp, color = Color.LightGray)
                    }
                }
            }
        }
    }
}

// 6. POPUP: SEARCH MODAL
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchCityPopUp(
    isHindi: Boolean,
    searchState: SearchUiState,
    searchQuery: String,
    onQueryChanged: (String) -> Unit,
    onSearchAction: (String) -> Unit,
    onResultSelected: (GeocodingResult) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = if (isHindi) "शहर खोजें" else "Search Global City",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                // Search Box
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onQueryChanged,
                    label = { Text(if (isHindi) "शहर का नाम (जैसे: मुंबई)" else "City name (e.g. New York)", color = Color.LightGray) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF38BDF8),
                        unfocusedBorderColor = Color.Gray
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("city_search_input")
                )

                Button(
                    onClick = { onSearchAction(searchQuery) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF38BDF8)),
                    modifier = Modifier.fillMaxWidth().testTag("search_action_button")
                ) {
                    Text(if (isHindi) "खोजें" else "Search Query", color = Color.Black, fontWeight = FontWeight.Bold)
                }

                // Results State
                when (searchState) {
                    is SearchUiState.Idle -> {}
                    is SearchUiState.Loading -> {
                        Box(modifier = Modifier.fillMaxWidth().height(100.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = Color(0xFF38BDF8))
                        }
                    }
                    is SearchUiState.Error -> {
                        Text(searchState.message, color = Color.Red, fontSize = 13.sp)
                    }
                    is SearchUiState.Success -> {
                        val results = searchState.results
                        if (results.isEmpty()) {
                            Text(
                                if (isHindi) "कोई परिणाम नहीं मिला। कृपया पुनः जांचें।" else "No matching cities. Try another name.",
                                color = Color.LightGray,
                                fontSize = 13.sp
                            )
                        } else {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 200.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(results) { city ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(0x1AFFFFFF))
                                            .clickable { onResultSelected(city) }
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(city.name, color = Color.White, fontWeight = FontWeight.Bold)
                                            Text("${city.admin1 ?: ""}, ${city.country ?: ""}", color = Color.LightGray, fontSize = 11.sp)
                                        }
                                        Icon(Icons.Filled.ArrowForward, null, tint = Color(0xFF38BDF8))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 7. DIALOG: REWARDED AD SIMULATION
@Composable
fun SimulatedRewardedAd(
    isHindi: Boolean,
    taskLabel: String,
    onAdCompleted: () -> Unit,
    onDismiss: () -> Unit
) {
    var timerCount by remember { mutableStateOf(3) }
    
    LaunchedEffect(Unit) {
        while (timerCount > 0) {
            delay(1000)
            timerCount--
        }
        onAdCompleted()
    }

    Dialog(onDismissRequest = {}) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.PlayCircleFilled,
                    contentDescription = null,
                    tint = Color(0xFFFACC15),
                    modifier = Modifier.size(64.dp)
                )

                Text(
                    text = if (isHindi) "अक्षर प्रीमियम विज्ञापन" else "Sponsored Rewarded Video",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Text(
                    text = if (isHindi) {
                        "आपकी विशिष्ट सेवा: '$taskLabel' को अनलॉक करने के लिए वीडियो को समाप्त होने का इंतजार करें।"
                    } else {
                        "Unlocking premium feature: '$taskLabel' once the video completes."
                    },
                    textAlign = TextAlign.Center,
                    color = Color.LightGray,
                    fontSize = 13.sp
                )

                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF1E293B)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "$timerCount",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFFFACC15)
                    )
                }

                Text(
                    text = if (isHindi) "विज्ञापनदाता प्रायोजक द्वारा सक्षम..." else "Ad Content by sponsored network...",
                    fontSize = 11.sp,
                    color = Color.DarkGray
                )
            }
        }
    }
}

// Helper: Weather code icon mapping
fun getWeatherIconComponent(code: Int): ImageVector {
    return when (code) {
        0 -> Icons.Filled.WbSunny
        1, 2, 3 -> Icons.Filled.WbCloudy
        45, 48 -> Icons.Filled.Grain
        51, 53, 55 -> Icons.Filled.WaterDrop
        56, 57 -> Icons.Filled.WaterDrop
        61, 63, 65 -> Icons.Filled.Thunderstorm
        66, 67 -> Icons.Filled.AcUnit
        71, 73, 75 -> Icons.Filled.AcUnit
        77 -> Icons.Filled.AcUnit
        80, 81, 82 -> Icons.Filled.Thunderstorm
        85, 86 -> Icons.Filled.AcUnit
        95, 96, 99 -> Icons.Filled.Thunderstorm
        else -> Icons.Filled.WbSunny
    }
}
