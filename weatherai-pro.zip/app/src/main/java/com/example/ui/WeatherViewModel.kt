package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.CityHistory
import com.example.data.model.GeocodingResult
import com.example.data.model.WeatherResponse
import com.example.data.repository.GeminiRepository
import com.example.data.repository.WeatherRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface WeatherUiState {
    object Loading : WeatherUiState
    data class Success(
        val weather: WeatherResponse,
        val cityName: String,
        val aiInsight: String = ""
    ) : WeatherUiState
    data class Error(val message: String) : WeatherUiState
}

sealed interface SearchUiState {
    object Idle : SearchUiState
    object Loading : SearchUiState
    data class Success(val results: List<GeocodingResult>) : SearchUiState
    data class Error(val message: String) : SearchUiState
}

class WeatherViewModel(
    private val weatherRepository: WeatherRepository,
    private val geminiRepository: GeminiRepository
) : ViewModel() {

    // Onboarding Status
    private val _onboardingCompleted = MutableStateFlow(false)
    val onboardingCompleted: StateFlow<Boolean> = _onboardingCompleted.asStateFlow()

    // Screen State: "splash", "onboarding", "dashboard", "history", "settings"
    private val _currentScreen = MutableStateFlow("splash")
    val currentScreen: StateFlow<String> = _currentScreen.asStateFlow()

    // Localization: English (false) vs Hindi (true)
    private val _isHindi = MutableStateFlow(false)
    val isHindi: StateFlow<Boolean> = _isHindi.asStateFlow()

    // Unit System: Celsius (true) vs Fahrenheit (false)
    private val _isCelsius = MutableStateFlow(true)
    val isCelsius: StateFlow<Boolean> = _isCelsius.asStateFlow()

    // Premium Subscription Status
    private val _isPremium = MutableStateFlow(false)
    val isPremium: StateFlow<Boolean> = _isPremium.asStateFlow()

    // AdMob test counters to trigger interstitial ads after every few transitions/searches
    private val _searchCount = MutableStateFlow(0)
    val searchCount: StateFlow<Int> = _searchCount.asStateFlow()

    // Weather Core UI State
    private val _weatherUiState = MutableStateFlow<WeatherUiState>(WeatherUiState.Loading)
    val weatherUiState: StateFlow<WeatherUiState> = _weatherUiState.asStateFlow()

    // Search Results State
    private val _searchUiState = MutableStateFlow<SearchUiState>(SearchUiState.Idle)
    val searchUiState: StateFlow<SearchUiState> = _searchUiState.asStateFlow()

    // Current City Coordinates
    private val _currentLatLong = MutableStateFlow<Pair<Double, Double>>(Pair(28.6139, 77.2090)) // Default: New Delhi
    val currentLatLong: StateFlow<Pair<Double, Double>> = _currentLatLong.asStateFlow()

    private val _currentCityName = MutableStateFlow("New Delhi")
    val currentCityName: StateFlow<String> = _currentCityName.asStateFlow()

    // Active Custom Visual Theme: "Vibrant Palette", "Ocean Breeze", "Forest Mist", "Cosmic Night", "Sunset Gold"
    private val _activeTheme = MutableStateFlow("Vibrant Palette")
    val activeTheme: StateFlow<String> = _activeTheme.asStateFlow()

    // Live Room DB history and bookmarks list
    val allHistory: StateFlow<List<CityHistory>> = weatherRepository.allCityHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteCities: StateFlow<List<CityHistory>> = weatherRepository.favoriteCities
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Automatically start by checking default coordinates
        loadWeatherForLocation(28.6139, 77.2090, "New Delhi")
    }

    fun completeOnboarding() {
        _onboardingCompleted.value = true
        _currentScreen.value = "dashboard"
    }

    fun navigateTo(screen: String) {
        _currentScreen.value = screen
    }

    fun toggleLanguage() {
        _isHindi.value = !_isHindi.value
        // Regenerate insight with new language context on toggle
        refreshCurrentWeather()
    }

    fun toggleUnit() {
        _isCelsius.value = !_isCelsius.value
    }

    fun setPremium(status: Boolean) {
        _isPremium.value = status
    }

    fun setTheme(theme: String) {
        _activeTheme.value = theme
    }

    fun incrementSearchCount() {
        _searchCount.value = _searchCount.value + 1
    }

    fun resetSearchCount() {
        _searchCount.value = 0
    }

    fun loadWeatherForLocation(lat: Double, lng: Double, cityName: String, bypassCache: Boolean = false) {
        _currentLatLong.value = Pair(lat, lng)
        _currentCityName.value = cityName
        _weatherUiState.value = WeatherUiState.Loading

        viewModelScope.launch {
            weatherRepository.getForecast(lat, lng, bypassCache).fold(
                onSuccess = { weatherResponse ->
                    // Fetch real-time unique Gemini advice based on the metrics
                    val description = getWeatherCodeDescription(weatherResponse.current?.weatherCode ?: 0, false)
                    val humidity = weatherResponse.current?.humidity ?: 50.0
                    val wind = weatherResponse.current?.windSpeed ?: 10.0
                    val temp = weatherResponse.current?.temperature ?: 20.0

                    // Insert query into Search History in Room
                    weatherRepository.insertCityHistory(
                        CityHistory(
                            cityName = cityName,
                            latitude = lat,
                            longitude = lng,
                            country = weatherResponse.timezone,
                            timestamp = System.currentTimeMillis()
                        )
                    )

                    try {
                        val insight = geminiRepository.getWeatherInsight(
                            cityName = cityName,
                            temperature = temp,
                            weatherDescription = description,
                            humidity = humidity,
                            windSpeed = wind,
                            isHindi = _isHindi.value
                        )
                        _weatherUiState.value = WeatherUiState.Success(
                            weather = weatherResponse,
                            cityName = cityName,
                            aiInsight = insight
                        )
                    } catch (e: Exception) {
                        _weatherUiState.value = WeatherUiState.Success(
                            weather = weatherResponse,
                            cityName = cityName,
                            aiInsight = "WeatherAI: Smooth wind and moderate humidity. Have a pleasant day!"
                        )
                    }
                },
                onFailure = { error ->
                    _weatherUiState.value = WeatherUiState.Error(
                        message = error.localizedMessage ?: "Failed to retrieve weather payload. Check your connectivity."
                    )
                }
            )
        }
    }

    fun searchCityAndLoad(query: String) {
        if (query.isBlank()) return
        _searchUiState.value = SearchUiState.Loading
        incrementSearchCount()

        viewModelScope.launch {
            weatherRepository.searchCity(query).fold(
                onSuccess = { geoResponse ->
                    val results = geoResponse.results
                    if (!results.isNullOrEmpty()) {
                        _searchUiState.value = SearchUiState.Success(results)
                    } else {
                        _searchUiState.value = SearchUiState.Success(emptyList())
                    }
                },
                onFailure = { error ->
                    _searchUiState.value = SearchUiState.Error(error.localizedMessage ?: "City not found.")
                }
            )
        }
    }

    fun clearSearchIdle() {
        _searchUiState.value = SearchUiState.Idle
    }

    fun refreshCurrentWeather() {
        val latLong = _currentLatLong.value
        loadWeatherForLocation(latLong.first, latLong.second, _currentCityName.value, bypassCache = true)
    }

    fun deleteHistoryItem(city: CityHistory) {
        viewModelScope.launch {
            weatherRepository.deleteCityHistory(city)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            weatherRepository.clearHistory()
        }
    }

    fun toggleFavoriteCity(cityName: String, isFavorite: Boolean) {
        viewModelScope.launch {
            val coords = _currentLatLong.value
            weatherRepository.insertCityHistory(
                CityHistory(
                    cityName = cityName,
                    latitude = coords.first,
                    longitude = coords.second,
                    country = "",
                    timestamp = System.currentTimeMillis(),
                    isFavorite = isFavorite
                )
            )
        }
    }

    // Convert code to localized string
    fun getWeatherCodeDescription(code: Int, inHindi: Boolean): String {
        return if (inHindi) {
            when (code) {
                0 -> "साफ़ आकाश"
                1, 2, 3 -> "आंशिक रूप से बादल"
                45, 48 -> "कोहरा और धुंध"
                51, 53, 55 -> "हल्की बूंदाबांदी"
                56, 57 -> "शीतल बूंदाबांदी"
                61, 63, 65 -> "वर्षा"
                66, 67 -> "ठंडी वर्षा"
                71, 73, 75 -> "बर्फबारी"
                77 -> "ओलावृष्टि"
                80, 81, 82 -> "तेज बौछारें"
                85, 86 -> "बर्फ की बौछारें"
                95, 96, 99 -> "गरज के साथ तूफान"
                else -> "सामान्य मौसम"
            }
        } else {
            when (code) {
                0 -> "Clear Sky"
                1, 2, 3 -> "Partly Cloudy"
                45, 48 -> "Foggy & Mist"
                51, 53, 55 -> "Light Drizzle"
                56, 57 -> "Freezing Drizzle"
                61, 63, 65 -> "Rainy"
                66, 67 -> "Freezing Rain"
                71, 73, 75 -> "Snowfall"
                77 -> "Snow Grains"
                80, 81, 82 -> "Rain Showers"
                85, 86 -> "Snow Showers"
                95, 96, 99 -> "Thunderstorm"
                else -> "Moderate Weather"
            }
        }
    }
}
