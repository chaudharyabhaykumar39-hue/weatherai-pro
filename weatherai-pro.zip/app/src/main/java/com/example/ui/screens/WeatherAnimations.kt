package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import kotlin.random.Random

@Composable
fun RainAnimation(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "rain")
    val rainProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rain_progress"
    )

    // Remember rain drop positions to avoid re-generating on recomposition
    val drops = remember {
        List(40) {
            Triple(
                Random.nextFloat(), // x percentage
                Random.nextFloat(), // y offset starting percent
                Random.nextFloat() * 15f + 15f // drop length
            )
        }
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        drops.forEach { drop ->
            val startX = drop.first * width
            // Slanted fall path
            val speedFactor = 1.2f
            val progressY = (drop.second + rainProgress * speedFactor) % 1f
            val startY = progressY * height
            val endX = startX - 5f // light angle
            val endY = startY + drop.third

            drawLine(
                color = Color(0x66B2EBF2),
                start = Offset(startX, startY),
                end = Offset(endX, endY),
                strokeWidth = 2.5f
            )
        }
    }
}

@Composable
fun SnowAnimation(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "snow")
    val snowProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "snow_progress"
    )

    val flakes = remember {
        List(30) {
            Pair(
                Random.nextFloat(), // x percentage
                Random.nextFloat() // size / radius
            )
        }
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        flakes.forEachIndexed { index, flake ->
            val startX = (flake.first * width + (snowProgress * 40f * if (index % 2 == 0) 1 else -1)) % width
            val progressY = (flake.first + snowProgress) % 1f
            val startY = progressY * height
            val radius = flake.second * 6.dp.toPx() + 2.dp.toPx()

            drawCircle(
                color = Color(0xAAFFFFFF),
                radius = radius,
                center = Offset(startX, startY)
            )
        }
    }
}

@Composable
fun SunnyAnimation(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "sun_glow")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "sun_scale"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        // Draw a glowing sun orb in top right of base canvas
        val cx = width * 0.85f
        val cy = 120.dp.toPx()
        val baseRadius = 80.dp.toPx()

        // Radial glow layers
        drawCircle(
            color = Color(0x11FFF9C4),
            radius = baseRadius * 2.2f * scale,
            center = Offset(cx, cy)
        )
        drawCircle(
            color = Color(0x22FFF59D),
            radius = baseRadius * 1.5f * scale,
            center = Offset(cx, cy)
        )
        drawCircle(
            color = Color(0x55FFE082),
            radius = baseRadius * scale,
            center = Offset(cx, cy)
        )
    }
}

// Support extension for converting Int to DP within Canvas context
private val Int.dp: androidx.compose.ui.unit.Dp
    get() = androidx.compose.ui.unit.Dp(this.toFloat())
