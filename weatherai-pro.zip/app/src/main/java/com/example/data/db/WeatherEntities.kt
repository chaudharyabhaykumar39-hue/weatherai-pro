package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cached_weather")
data class CachedWeather(
    @PrimaryKey val locationKey: String, // "current" or "lat_lng"
    val weatherJson: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "city_history")
data class CityHistory(
    @PrimaryKey val cityName: String,
    val latitude: Double,
    val longitude: Double,
    val country: String?,
    val timestamp: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false
)
