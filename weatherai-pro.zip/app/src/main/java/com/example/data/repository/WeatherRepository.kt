package com.example.data.repository

import com.example.data.api.GeocodingApiService
import com.example.data.api.WeatherApiService
import com.example.data.db.CachedWeather
import com.example.data.db.CityHistory
import com.example.data.db.WeatherDao
import com.example.data.model.GeocodingResponse
import com.example.data.model.WeatherResponse
import com.squareup.moshi.Moshi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class WeatherRepository(
    private val weatherApi: WeatherApiService,
    private val geocodingApi: GeocodingApiService,
    private val weatherDao: WeatherDao,
    private val moshi: Moshi
) {
    private val weatherAdapter = moshi.adapter(WeatherResponse::class.java)

    // Fetch and cache weather
    suspend fun getForecast(latitude: Double, longitude: Double, bypassCache: Boolean = false): Result<WeatherResponse> {
        val cacheKey = "lat_lng_${String.format("%.3f", latitude)}_${String.format("%.3f", longitude)}"
        
        return withContext(Dispatchers.IO) {
            try {
                // Check cache if not bypassing
                if (!bypassCache) {
                    val cached = weatherDao.getCachedWeather(cacheKey)
                    if (cached != null && (System.currentTimeMillis() - cached.timestamp < 15 * 60 * 1000)) { // 15 mins cache
                        val weather = weatherAdapter.fromJson(cached.weatherJson)
                        if (weather != null) {
                            return@withContext Result.success(weather)
                        }
                    }
                }
                
                // Fetch from API
                val response = weatherApi.getForecast(latitude, longitude)
                
                // Save to cache
                val json = weatherAdapter.toJson(response)
                weatherDao.insertCachedWeather(CachedWeather(cacheKey, json))
                
                Result.success(response)
            } catch (e: Exception) {
                // On error, try to return expired cached weather before throwing failure
                try {
                    val cached = weatherDao.getCachedWeather(cacheKey)
                    if (cached != null) {
                        val weather = weatherAdapter.fromJson(cached.weatherJson)
                        if (weather != null) {
                            return@withContext Result.success(weather)
                        }
                    }
                } catch (ignore: Exception) {}
                
                Result.failure(e)
            }
        }
    }

    // Search city name
    suspend fun searchCity(cityName: String): Result<GeocodingResponse> {
        return withContext(Dispatchers.IO) {
            try {
                val results = geocodingApi.searchCity(cityName)
                Result.success(results)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    // Database: Saved City History
    val allCityHistory: Flow<List<CityHistory>> = weatherDao.getAllCityHistory()
    val favoriteCities: Flow<List<CityHistory>> = weatherDao.getFavoriteCities()

    suspend fun insertCityHistory(city: CityHistory) {
        withContext(Dispatchers.IO) {
            weatherDao.insertCityHistory(city)
        }
    }

    suspend fun deleteCityHistory(city: CityHistory) {
        withContext(Dispatchers.IO) {
            weatherDao.deleteCityHistory(city)
        }
    }

    suspend fun clearHistory() {
        withContext(Dispatchers.IO) {
            weatherDao.clearHistory()
        }
    }
}
