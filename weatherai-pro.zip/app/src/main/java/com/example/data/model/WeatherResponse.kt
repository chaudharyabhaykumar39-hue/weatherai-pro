package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class WeatherResponse(
    val latitude: Double,
    val longitude: Double,
    val timezone: String,
    val current: CurrentWeather?,
    val hourly: HourlyForecast?,
    val daily: DailyForecast?
)

@JsonClass(generateAdapter = true)
data class CurrentWeather(
    val time: String,
    val interval: Int,
    @Json(name = "temperature_2m") val temperature: Double,
    @Json(name = "relative_humidity_2m") val humidity: Double,
    @Json(name = "apparent_temperature") val apparentTemperature: Double,
    @Json(name = "weather_code") val weatherCode: Int,
    @Json(name = "pressure_msl") val pressure: Double,
    @Json(name = "wind_speed_10m") val windSpeed: Double,
    @Json(name = "uv_index") val uvIndex: Double,
    val visibility: Double
)

@JsonClass(generateAdapter = true)
data class HourlyForecast(
    val time: List<String>,
    @Json(name = "temperature_2m") val temperatures: List<Double>,
    @Json(name = "apparent_temperature") val apparentTemperatures: List<Double>,
    @Json(name = "precipitation_probability") val precipitationProbabilities: List<Int>,
    @Json(name = "weather_code") val weatherCodes: List<Int>,
    @Json(name = "wind_speed_10m") val windSpeeds: List<Double>
)

@JsonClass(generateAdapter = true)
data class DailyForecast(
    val time: List<String>,
    @Json(name = "weather_code") val weatherCodes: List<Int>,
    @Json(name = "temperature_2m_max") val maxTemperatures: List<Double>,
    @Json(name = "temperature_2m_min") val minTemperatures: List<Double>,
    @Json(name = "apparent_temperature_max") val maxApparentTemperatures: List<Double>,
    @Json(name = "apparent_temperature_min") val minApparentTemperatures: List<Double>,
    val sunrise: List<String>,
    val sunset: List<String>,
    @Json(name = "uv_index_max") val maxUvIndexes: List<Double>
)
