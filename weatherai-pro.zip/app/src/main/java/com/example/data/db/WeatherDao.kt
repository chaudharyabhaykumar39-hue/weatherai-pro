package com.example.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface WeatherDao {
    // Weather Caching
    @Query("SELECT * FROM cached_weather WHERE locationKey = :key")
    suspend fun getCachedWeather(key: String): CachedWeather?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCachedWeather(weather: CachedWeather)

    @Query("DELETE FROM cached_weather WHERE locationKey = :key")
    suspend fun deleteCachedWeather(key: String)

    // City History / Saved Locations
    @Query("SELECT * FROM city_history ORDER BY timestamp DESC")
    fun getAllCityHistory(): Flow<List<CityHistory>>

    @Query("SELECT * FROM city_history WHERE isFavorite = 1 ORDER BY cityName ASC")
    fun getFavoriteCities(): Flow<List<CityHistory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCityHistory(city: CityHistory)

    @Delete
    suspend fun deleteCityHistory(city: CityHistory)

    @Query("DELETE FROM city_history")
    suspend fun clearHistory()
}
