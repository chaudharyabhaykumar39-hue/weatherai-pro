package com.example.data.repository

import com.example.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.JsonClass
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException

@JsonClass(generateAdapter = true)
data class GeminiRequest(
    val contents: List<GeminiContent>
)

@JsonClass(generateAdapter = true)
data class GeminiContent(
    val parts: List<GeminiPart>
)

@JsonClass(generateAdapter = true)
data class GeminiPart(
    val text: String
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    val candidates: List<GeminiCandidate>?
)

@JsonClass(generateAdapter = true)
data class GeminiCandidate(
    val content: GeminiContent?
)

class GeminiRepository(
    private val moshi: Moshi,
    private val okHttpClient: OkHttpClient
) {
    private val requestAdapter = moshi.adapter(GeminiRequest::class.java)
    private val responseAdapter = moshi.adapter(GeminiResponse::class.java)

    suspend fun getWeatherInsight(
        cityName: String,
        temperature: Double,
        weatherDescription: String,
        humidity: Double,
        windSpeed: Double,
        isHindi: Boolean
    ): String {
        return withContext(Dispatchers.IO) {
            val apiKey = BuildConfig.GEMINI_API_KEY
            if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
                return@withContext if (isHindi) {
                    "मौसम प्रो अंतर्दृष्टि: वर्तमान में $weatherDescription के साथ तापमान ${temperature}°C है। हल्के और आरामदायक कपड़े पहनें और अपने दिन का आनंद लें!"
                } else {
                    "WeatherAI Pro Insight: Currently in $cityName, it is ${temperature}°C with $weatherDescription. Wear comfortable light clothing and enjoy your day!"
                }
            }

            val prompt = if (isHindi) {
                """
                आप एक बुद्धिमान मौसम सलाहकार हैं। वर्तमान मौसम विवरण के आधार पर एक छोटा, आकर्षक और मददगार 2-लाइन का विश्लेषण और पहनने योग्य कपड़ों की सलाह लिखें।
                शहर: $cityName
                तापमान: ${temperature}°C
                स्थिति: $weatherDescription
                आर्द्रता: $humidity%
                हवा की गति: ${windSpeed} किमी/घंटा
                भाषा: हिंदी
                कृपया बिना किसी तकनीकी संकेतकों के, प्राकृतिक, स्नेही शैली में उत्तर दें।
                """.trimIndent()
            } else {
                """
                You are a smart, witty WeatherAI advisor. Write a friendly, engaging, and brief 2-sentence weather commentary along with outfit recommendations.
                City: $cityName
                Temperature: ${temperature}°C
                Condition: $weatherDescription
                Humidity: $humidity%
                Wind Speed: ${windSpeed} km/h
                Language: English
                Keep it natural, lighthearted, and professional. Do not include markdown headers or brackets.
                """.trimIndent()
            }

            val geminiRequest = GeminiRequest(
                contents = listOf(
                    GeminiContent(
                        parts = listOf(
                            GeminiPart(text = prompt)
                        )
                    )
                )
            )

            val jsonBody = requestAdapter.toJson(geminiRequest)
            val mediaType = "application/json; charset=utf-8".toMediaType()
            val requestBody = jsonBody.toRequestBody(mediaType)

            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"

            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            try {
                okHttpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        return@withContext getFallbackInsight(cityName, temperature, weatherDescription, isHindi)
                    }
                    val bodyString = response.body?.string() ?: return@withContext getFallbackInsight(cityName, temperature, weatherDescription, isHindi)
                    val geminiRes = responseAdapter.fromJson(bodyString)
                    val textResult = geminiRes?.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    
                    if (!textResult.isNullOrBlank()) {
                        textResult.trim()
                    } else {
                        getFallbackInsight(cityName, temperature, weatherDescription, isHindi)
                    }
                }
            } catch (e: IOException) {
                getFallbackInsight(cityName, temperature, weatherDescription, isHindi)
            }
        }
    }

    private fun getFallbackInsight(
        cityName: String,
        temperature: Double,
        weatherDescription: String,
        isHindi: Boolean
    ): String {
        return if (isHindi) {
            "मौसम अंतर्दृष्टि: ${cityName} में ${temperature}°C और ${weatherDescription} है। उपयुक्त पोशाक पहनें, पानी पीते रहें, और सुरक्षित रहें!"
        } else {
            "Weather Insight: Currently ${temperature}°C and ${weatherDescription} in ${cityName}. Dress appropriately, stay hydrated, and stay safe!"
        }
    }
}
